const cards = document.querySelectorAll(".card");

let matchedCard = 0;
let cardOne, cardTwo;
let disableDeck = false;
let score = 0;

function updateScore() {
    document.getElementById("score").textContent = score;
  }

function flipCard(e) {
    let clickedCard = e.target;  
    if(clickedCard !== cardOne && !disableDeck) {
        clickedCard.classList.add("flip");
        if(!cardOne){
            return cardOne = clickedCard;
        }
        cardTwo = clickedCard;
        disableDeck = true;
        let cardOneimg = cardOne.querySelector("img").src,
        cardTwoimg = cardTwo.querySelector("img").src;
        matchCards(cardOneimg, cardTwoimg);
    
    }
}

async function getTriviaQuestion() {
    try {
        const response = await fetch("https://opentdb.com/api.php?amount=15&category=23&difficulty=easy&type=multiple");
        const data = await response.json();
        return data.results[0];
    } catch (error) {
        console.error("Failed to fetch trivia question:", error);
    }
}

function showTriviaPopup(question, answers, correctAnswer) {
    const popup = document.createElement("div");
    popup.className = "trivia-popup";
    popup.style.position = "fixed";
    popup.style.top = "50%";
    popup.style.left = "50%";
    popup.style.transform = "translate(-50%, -50%)";
    popup.style.background = "white";
    popup.style.border = "2px solid #586ff1";
    popup.style.padding = "30px";
    popup.style.width = "300px";
    popup.style.textAlign = "center";
    popup.style.borderRadius = "10px";
    popup.style.boxShadow = "0 3 10px rgba(0, 0, 0, 0.1)";
    popup.style.zIndex = "1000";
    popup.style.fontFamily = " 'Poppins', sans-serif";

    popup.innerHTML = `
        <div style="margin-bottom: 15px; font-weight: bold;">${question}</div>
        <div class="trivia-answers"></div>
    `;


    const answersContainer = popup.querySelector(".trivia-answers");
    answers.forEach(answer => {
        const btn = document.createElement("button");
        btn.textContent = answer;
        btn.style.margin = "5px";
        btn.style.padding = "10px 15px";
        btn.style.cursor = "pointer";

        btn.addEventListener("click", () => {
            if (answer === correctAnswer) {
                alert("Correct!");
                score += 20;
                updateScore();
            } else {
                alert("Wrong! Try again!");
            } 
        
            document.body.removeChild(popup);
        });
        

        answersContainer.appendChild(btn);
    });

    document.body.appendChild(popup);
}

function showGameEndPopup() {
    const popup = document.createElement("div");
    popup.className = "game-end-popup";
    popup.style.position = "fixed";
    popup.style.top = "50%";
    popup.style.left = "50%";
    popup.style.transform = "translate(-50%, -50%)";
    popup.style.background = "white";
    popup.style.border = "2px solid #586ff1";
    popup.style.padding = "30px";
    popup.style.width = "300px";
    popup.style.textAlign = "center";
    popup.style.borderRadius = "10px";
    popup.style.boxShadow = "0 3px 10px rgba(0, 0, 0, 0.1)";
    popup.style.zIndex = "1000";
    popup.style.fontFamily = "'Poppins', sans-serif";

    popup.innerHTML = `
        <div style="margin-bottom: 15px; font-weight: bold; font-size: 20px;">Game Over!</div>
        <div style="margin-bottom: 15px;">Your final score is: <strong>${score}</strong></div>
        <button class="restart-btn">Play Again</button>
    `;

    const restartBtn = popup.querySelector(".restart-btn");
    restartBtn.style.padding = "10px 15px";
    restartBtn.style.cursor = "pointer";
    restartBtn.style.background = "#586ff1";
    restartBtn.style.color = "white";
    restartBtn.style.border = "none";
    restartBtn.style.borderRadius = "5px";
    restartBtn.style.transition = "background 0.3s";
    restartBtn.addEventListener("click", () => {
        document.body.removeChild(popup);
        shuffleCard(); // Restart the game
        score = 0;
        updateScore();
    });

    document.body.appendChild(popup);
}

function matchCards(img1, img2){
    if(img1 === img2) {
        matchedCard++;
        score += 10;
        updateScore();

        if (matchedCard == 8) { // All cards are matched
            setTimeout(() => {
                showGameEndPopup(); // Show game-end popup
            }, 1000);
            
        }
        cardOne.removeEventListener("click",flipCard);
        cardTwo.removeEventListener("click",flipCard);

    getTriviaQuestion().then(questionData => {
        if (questionData) {
            const question = questionData.question;
            const correctAnswer = questionData.correct_answer;
            const answers = [...questionData.incorrect_answers, correctAnswer].sort(() => Math.random() - 0.5);
            showTriviaPopup(question, answers, correctAnswer);
        }
    });

        cardOne = cardTwo = "";
        return disableDeck = false;

    }



    setTimeout(() => {
        cardOne.classList.add("shake");
        cardTwo.classList.add("shake");
    }, 400);

    
    setTimeout(() => {
        cardOne.classList.remove("shake","flip");
        cardTwo.classList.remove("shake","flip");
        cardOne = cardTwo = "";
        disableDeck = false;
    }, 1200);
}

function shuffleCard(){
    matchedCard = 0;
    cardOne = cardTwo = "";  

    let arr = [1, 2, 3, 4, 5, 6, 7, 8, 1, 2, 3, 4, 5, 6, 7, 8];
    arr.sort(() => Math.random() > 0.5 ? 1 : -1 );

    cards.forEach((card, index) => {
        card.classList.remove("flip");
        let imgTag = card.querySelector("img");
        imgTag.src = `images/img-${arr[index]}.png`; 
        card.addEventListener("click", flipCard);
    });

}



shuffleCard();

